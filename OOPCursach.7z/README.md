Kursach po OOP
